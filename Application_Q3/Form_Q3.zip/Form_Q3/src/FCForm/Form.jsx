import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControl from '@mui/material/FormControl';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import AccountCircle from '@mui/icons-material/AccountCircle';
import IconButton from '@mui/material/IconButton';
import { InputLabel } from '@mui/material';
import AlternateEmailIcon from '@mui/icons-material/AlternateEmail';
import LockIcon from '@mui/icons-material/Lock';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import LoginIcon from '@mui/icons-material/Login';

export default function FormPropsTextFields() {
    const [showPassword, setShowPassword] = React.useState(false);
    const [users, setUsers] = React.useState();
    const [user,setUser] = React.useState({username:"",password:"",email:""});

    function handleClickShowPassword() {
        return setShowPassword((show) => !show);
    }
  
    const handleMouseDownPassword = (event) => {
      event.preventDefault();
    
    }
    
    React.useEffect(() => {
     
        loadUsers();
        console.log(22)
    },[]);

  function loadUsers(){
    if (localStorage["users"] != null) {
      setUsers(JSON.parse(localStorage["users"]));
      }
     else 
         {
        setUsers([]);
        }
     console.log(users)
      return users;
  }
   function registerUser(){
      setUser(user);
      setUsers([...users,user]);
      localStorage["users"] = JSON.stringify(users)
     
   } 
   
   function loginUser(username,password){
    let login = {username , password}  
    let d = JSON.parse(localStorage["users"])
    console.log(d);
   }
  return (
    <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m:1.5, width: '35ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <div>
      <TextField
      required
        id="username"
        onChange={(e) =>{setUser({...user,username:e.target.value,})}}
        label="Required"
        placeholder='Username'
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <AccountCircle />
            </InputAdornment>
          ),
        }}
        variant="outlined"
      />
        <br />
        <FormControl sx={{ m: 1.5, width: '35ch' }} variant="outlined">
        <InputLabel required >Required</InputLabel>
          <OutlinedInput
            placeholder="password"
            onChange={(e) =>{setUser({...user,password:e.target.value,})}}
            id="password"
            type={showPassword ? 'text' : 'password'}
            startAdornment = {<InputAdornment position='start'> 
                <LockIcon />
            </InputAdornment>

            }
            endAdornment={
              <InputAdornment htmlFor="outlined-adornment-password" position="end">
                 
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
        </FormControl><br />
        <TextField
      required
        id="email"
        onChange={(e) =>{setUser({...user,email:e.target.value,})}}
        label="Required"
        placeholder='Email'
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <AlternateEmailIcon />
            </InputAdornment>
          ),
        }}
        variant="outlined"
      />
     <br />
     <Button variant="outlined"onClick={loginUser(user.username,user.password)}endIcon={<LoginIcon />}>
        LogIn
      </Button> <t />
     <Button variant="outlined" onClick={registerUser} endIcon={<PersonAddAlt1Icon />}>
        Add User
      </Button> <t />
      <Button variant="outlined" endIcon={<DeleteIcon />}>
        Delete
      </Button> 
     
      </div>
    
    </Box>
  );
}
